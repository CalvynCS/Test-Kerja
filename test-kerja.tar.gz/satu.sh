#!/bin/bash

FOLDER="test/Test-Kerja"
EXTENTION="*.sh"

find ~/"$FOLDER" -type f -name "$EXTENTION"
