#!/bin/bash

SOURCE_DIR="."
DESTINATION_DIR="."

tar -czvf "$DESTINATION_DIR"/test-kerja.tar.gz "$SOURCE_DIR"